<?php
//__NM____NM__FUNCTION__NM__//
	function fnprueba(){
	echo 'Hola';
}
?>